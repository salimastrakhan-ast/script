#!/bin/bash

# актуализация переменной директории приложения. на слуачй если приложение было перемещено
hrlink_home=$(docker inspect --format '{{ index .Config.Labels "com.docker.compose.project.working_dir" }}' ekd-monolith)
if grep -q "^HRLINK_HOME" "$hrlink_home/.env"; then
    sed -i "s|HRLINK_HOME=.*|HRLINK_HOME=$hrlink_home|" "$hrlink_home/.env"
else
    echo -e "\nHRLINK_HOME=$hrlink_home" >> "$hrlink_home/.env"
fi

cd $hrlink_home

# скачивание актуального ekd-charon для применения изменений в скриптах, используемых cron-задачами
docker compose pull ekd-charon
docker compose up -d ekd-charon
