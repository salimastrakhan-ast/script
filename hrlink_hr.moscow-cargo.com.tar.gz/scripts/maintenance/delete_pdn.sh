#!/bin/bash

# METADATA_START
# date_added: 2025-12-03
# desc: Скрипт для удаления ПДн ФЛ в БД
# last_tested_release: 95
# METADATA_END

MAINTENANCE_DELETE_PDN_VERSION="95.0"

docker_pfx=""
if [[ -n "$(command -v docker)" ]] && [[ -n "$(docker container ls --format 'table {{.Names}}' 2>/dev/null | grep 'ekd-postgresql')" ]]; then
       docker_pfx="docker exec --user postgres ekd-postgresql"
fi

get_db() {
    local db_name=$1
    if [[ "$db_name" == 'ekd_file' ]]; then
            db_name='ekd_file_[^proc%]'
    fi

    result=$($docker_pfx psql -A -t -c "
    SELECT
        CASE
            WHEN datname ~ '_main' THEN datname
            ELSE (SELECT datname FROM pg_database WHERE datname ~ '_$db_name' LIMIT 1)
        END AS dn
    FROM pg_database
    WHERE (datname ~ '_main' OR datname ~ '_$db_name') AND datname IS NOT NULL AND datallowconn IS true LIMIT 1;")

    echo "$result"
}

employee_id=$1

if [[ -z "${employee_id}" ]]; then
    echo "Введите id сотрудника (id сотрудника содержит ссылка на этого сотрудника https://<домен>/hr/employees/<id сотрудника>)"
    read employee_id
fi

FIO=$($docker_pfx psql --dbname $(get_db 'ekd_ekd') -A -t -c "
SELECT CONCAT_WS(' ', last_name, first_name, patronymic)
FROM ekd_id.person
LEFT JOIN ekd_ekd.client_user ON person.user_id = client_user.user_id
LEFT JOIN ekd_ekd.employee ON employee.client_user_id = client_user.id
WHERE employee.id = '$employee_id';
")

pre_delete_pdn() {
    while true; do
        read -rp "Вы точно хотите удалить пользователя c ФИО \"$FIO\"? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                delete_pdn
                break
                ;;
            [Nn]|"")
                echo "Удаление отменено"
                break
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

delete_pdn() {
    $docker_pfx psql --dbname $(get_db 'ekd_ekd') -c "
    CREATE EXTENSION IF NOT EXISTS dblink;
    DO
    \$\$
        DECLARE
            l_user_id          uuid;
            l_empl             uuid;
            l_old_data         record;
            l_person_id        uuid;
            l_client_id        uuid;
            a_empl_list        uuid[] := ARRAY ['$employee_id']; -- Сюда employee_id через запятую, если более 1го
            a_all_employee_ids uuid[]; -- массив для ВСЕХ сотрудников пользователя
            l_empl_found       boolean; -- Для проверки существования employee_id (Добавил АЕГ 11.11.2025)
            l_fio              text;
            l_row_count        integer;
            l_table_exists     boolean;
    
        BEGIN
            CREATE TABLE IF NOT EXISTS temp_del_log
            (
                db_name      text      DEFAULT CURRENT_DATABASE() NOT NULL,
                table_name   text                                 NOT NULL,
                data         jsonb                                NOT NULL,
                deleter      text      DEFAULT CURRENT_USER,
                schema       text,
                user_id      uuid,
                created_date timestamp DEFAULT NOW()              NOT NULL
            );
    
            FOREACH l_empl IN ARRAY a_empl_list
                LOOP
                    l_empl_found := FALSE;
                    l_user_id := NULL;
    
                    -- Проверяем существование сотрудника (Добавил АЕГ 11.11.2025)
                    SELECT COUNT(*) > 0
                    INTO l_empl_found
                    FROM ekd_ekd.employee
                    WHERE employee.id = l_empl;
    
                    -- Если сотрудник не найден, пропускаем с сообщением (Добавил АЕГ 11.11.2025)
                    IF NOT l_empl_found THEN
                        RAISE NOTICE 'Сотрудник с id % не найден, пропускаем', l_empl;
                        CONTINUE;
                    END IF;
    
                    -- Получаем user_id для найденного сотрудника
                    SELECT client_user.user_id
                    INTO l_user_id
                    FROM ekd_ekd.employee
                             LEFT JOIN ekd_ekd.client_user ON employee.client_user_id = client_user.id
                    WHERE employee.id = l_empl;
    
                    -- Получаем person_id для найденного сотрудника
                    SELECT id
                    INTO l_person_id
                    FROM ekd_id.person
                    WHERE user_id = l_user_id;
    
                    -- Получаем ФИО (Добавил АЕГ 11.11.2025)
                    SELECT CONCAT_WS(' ', last_name, first_name, patronymic)
                    INTO l_fio
                    FROM ekd_id.person
                    WHERE user_id = l_user_id;
    
                    SELECT id
                    INTO l_client_id
                    FROM ekd_ekd.client;
    
                    -- Находим ВСЕХ сотрудников этого пользователя (Добавил АЕГ 27.10.2025)
                    SELECT COALESCE(ARRAY_AGG(employee.id), ARRAY []::uuid[])
                    INTO a_all_employee_ids
                    FROM ekd_ekd.employee
                             LEFT JOIN ekd_ekd.client_user ON employee.client_user_id = client_user.id
                    WHERE client_user.user_id = l_user_id;
    
                    RAISE NOTICE 'Обработка пользователя %, person_id %, найдено сотрудников: %', l_fio, l_person_id, ARRAY_LENGTH(a_all_employee_ids, 1);
    
                    -- Обрабатываем ВСЕХ сотрудников пользователя (Добавил цикл АЕГ 27.10.2025)
                    IF ARRAY_LENGTH(a_all_employee_ids, 1) > 0 THEN -- проверка что сотрудник есть (Добавил АЕГ 11.11.2025)
                        FOREACH l_empl IN ARRAY a_all_employee_ids
                            LOOP
                                -- Логирование данных employee
                                FOR l_old_data IN (SELECT *
                                                   FROM ekd_ekd.employee
                                                   WHERE id = l_empl)
                                    LOOP
                                        INSERT INTO temp_del_log (table_name, data, schema, user_id)
                                        VALUES ('employee', ROW_TO_JSON(l_old_data), 'ekd_ekd', l_user_id);
                                    END LOOP;
    
                                -- Затирание внешнего ID сотрудника
                                UPDATE ekd_ekd.employee
                                SET external_id = public.uuid_generate_v4()
                                WHERE id = l_empl;
    
                                -- Проставить дату увольнения, если нет (Добавил АЕГ 27.10.2025)
                                UPDATE ekd_ekd.employee
                                SET dismissed_date = '2020-01-01 00:00:00'
                                WHERE id = l_empl
                                  AND dismissed_date IS NULL;
    
                                -- Отключаем повторные уведомления (Добавил АЕГ 27.10.2025)
                                PERFORM public.dblink('dbname=ekd_repeat_notification_db',
                                               'INSERT INTO employee_reference(id)
                                                SELECT ''' || l_empl || '''
                                                WHERE NOT EXISTS (SELECT 1 FROM employee_reference WHERE id = ''' ||
                                               l_empl || ''');
    
                                                INSERT INTO notifying_stopped_employee(employee_id, stop_reason)
                                                SELECT ''' || l_empl || ''', ''DISMISSED''
                                                WHERE NOT EXISTS (SELECT 1 FROM notifying_stopped_employee WHERE employee_id = ''' ||
                                               l_empl || ''');
                                ');
                                RAISE NOTICE 'Затерт сотрудник с id %', l_empl;
                            END LOOP;
                    END IF;
    
                    FOR l_old_data IN (SELECT *
                                       FROM ekd_id.user_external_id
                                       WHERE user_id = l_user_id)
                        LOOP
                            INSERT INTO temp_del_log (table_name, data, schema, user_id)
                            VALUES ('user_external_id', ROW_TO_JSON(l_old_data), 'ekd_id', l_user_id);
                        END LOOP;
    
                    -- Затирание данных для внешних систем
                    UPDATE ekd_id.user_external_id
                    SET value = public.uuid_generate_v4()
                    WHERE user_id = l_user_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерто user_external_id: %', l_row_count;
    
    
                    SELECT *
                    INTO l_old_data
                    FROM ekd_ekd.client_user
                    WHERE user_id = l_user_id;
    
                    INSERT INTO temp_del_log (table_name, data, schema, user_id)
                    VALUES ('client_user', ROW_TO_JSON(l_old_data), 'ekd_ekd', l_user_id);
    
                    -- Затирание внешнего ID пользователя
                    UPDATE ekd_ekd.client_user
                    SET external_id = public.uuid_generate_v4()
                    WHERE id = (SELECT client_user_id FROM ekd_ekd.employee WHERE id = l_empl);
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерто external_id client_user: %', l_row_count;
    
    
                    FOR l_old_data IN (SELECT *
                                       FROM ekd_ca.nqes_issue_request
                                       WHERE person_id = l_person_id)
                        LOOP
                            INSERT INTO temp_del_log (table_name, data, schema, user_id)
                            VALUES ('nqes_issue_request', ROW_TO_JSON(l_old_data), 'ekd_ca', l_user_id);
                        END LOOP;
    
                    -- Затирание данных в запросах на выпуск УНЭП
                    UPDATE ekd_ca.nqes_issue_request
                    SET data ='{}'
                    WHERE person_id = l_person_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерто данных nqes_issue_request: %', l_row_count;
    
    
                    FOR l_old_data IN (SELECT *
                                       FROM ekd_ca.nqes_issue_task
                                       WHERE user_id = l_user_id)
                        LOOP
                            INSERT INTO temp_del_log (table_name, data, schema, user_id)
                            VALUES ('nqes_issue_task', ROW_TO_JSON(l_old_data), 'ekd_ca', l_user_id);
                        END LOOP;
    
                    -- Затирание данных в задачах на выпуск УНЭП
                    UPDATE ekd_ca.nqes_issue_task
                    SET data ='{}'
                    WHERE user_id = l_user_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерто данных nqes_issue_task: %', l_row_count;
    
    
                    FOR l_old_data IN (SELECT *
                                       FROM ekd_id.person_document
                                       WHERE person_id = l_person_id)
                        LOOP
                            INSERT INTO temp_del_log (table_name, data, schema, user_id)
                            VALUES ('person_document', ROW_TO_JSON(l_old_data), 'ekd_id', l_user_id);
                        END LOOP;
    
                    -- Затирание данных паспорта (Переделал АЕГ 27.10.2025)
                    UPDATE ekd_id.person_document
                    SET (document_data, number) = ('{}', public.uuid_generate_v4())
                    WHERE person_id = l_person_id
                      AND document_type = 'PASSPORT';
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерт паспорт: %', l_row_count;
    
                    -- Затирание данных СНИЛС и ИНН (Переделал АЕГ 27.10.2025)
                    UPDATE ekd_id.person_document
                    SET number = public.uuid_generate_v4()
                    WHERE person_id = l_person_id
                      AND document_type IN ('SNILS', 'INN');
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерт СНИЛС/ИНН: %', l_row_count;
    
                    SELECT *
                    INTO l_old_data
                    FROM ekd_id.person_certificate
                    WHERE person_id = l_person_id;
    
                    FOR l_old_data IN (SELECT *
                                       FROM ekd_id.person_certificate
                                       WHERE person_id = l_person_id)
                        LOOP
                            INSERT INTO temp_del_log (table_name, data, schema, user_id)
                            VALUES ('person_certificate', ROW_TO_JSON(l_old_data), 'ekd_id', l_user_id);
                        END LOOP;
    
                    -- Затирание данных в выпущенных УНЭП
                    UPDATE ekd_id.person_certificate
                    SET (last_name, first_name, patronymic, company_name, inn, snils,
                         confirmation_channel) = (public.uuid_generate_v4(),
                                                  public.uuid_generate_v4(),
                                                  public.uuid_generate_v4(),
                                                  public.uuid_generate_v4(),
                                                  public.uuid_generate_v4(),
                                                  public.uuid_generate_v4(),
                                                  public.uuid_generate_v4())
                    WHERE person_id = l_person_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерты данные УНЭП: %', l_row_count;
    
                    SELECT *
                    INTO l_old_data
                    FROM ekd_id.person
                    WHERE user_id = l_user_id;
    
                    INSERT INTO temp_del_log (table_name, data, schema, user_id)
                    VALUES ('person', ROW_TO_JSON(l_old_data), 'ekd_id', l_user_id);
    
                    -- Изменение ФИО в данных пользователя
                    UPDATE ekd_id.person
                    SET (last_name, first_name, patronymic) = ('Персональные', 'данные удалены по', ' заявлению пользователя')
                    WHERE user_id = l_user_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Изменено ФИО в person: %', l_row_count;
    
                    -- Изменение ФИО в employee_cache (Добавил АЕГ 27.10.2025)(11.11.2025 добавил проверку существования employee_cache, для работы со старыми релизами)
                    SELECT EXISTS (SELECT 1
                                   FROM information_schema.tables
                                   WHERE table_schema = 'ekd_ekd'
                                     AND table_name = 'employee_cache')
                    INTO l_table_exists;
    
                    IF l_table_exists THEN
                        UPDATE ekd_ekd.employee_cache
                        SET (last_name, first_name, patronymic) = ('Персональные', 'данные удалены по', ' заявлению пользователя')
                        WHERE user_id = l_user_id;
                        GET DIAGNOSTICS l_row_count = ROW_COUNT;
                        RAISE NOTICE '  Изменено ФИО в employee_cache: %', l_row_count;
                    ELSE
                        RAISE NOTICE '  Таблица employee_cache не существует, пропускаем';
                    END IF;
    
    
                    FOR l_old_data IN (SELECT * FROM ekd_id.user_login WHERE user_id = l_user_id)
                        LOOP
                            INSERT INTO temp_del_log (table_name, data, schema, user_id)
                            VALUES ('user_login', ROW_TO_JSON(l_old_data), 'ekd_id', l_user_id);
                        END LOOP;
    
    
                    -- Затирание логинов
                    UPDATE ekd_id.user_login
                    SET login = public.uuid_generate_v4()
                    WHERE user_id = l_user_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Затерто логинов: %', l_row_count;
    
                    -- Отключение всех каналов уведомлений (Добавил АЕГ 27.10.2025)
                    UPDATE ekd_id.notification_channel
                    SET enabled = FALSE
                    WHERE user_id = l_user_id;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Отключено каналов уведомлений: %', l_row_count;
    
                    -- Отмена приглашений (Добавил АЕГ 27.10.2025)
                    UPDATE ekd_id.user_invitation
                    SET deactivated_date = NOW()
                    WHERE user_id = l_user_id
                      AND deactivated_date IS NULL
                      AND accepted_date IS NULL;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Отменено приглашений: %', l_row_count;
    
                    -- Отключение пользователя (Добавил АЕГ 27.10.2025)
                    UPDATE ekd_id.\"user\"
                    SET disabled_date = now()
                    WHERE id = l_user_id
                      AND disabled_date IS NULL;
                    GET DIAGNOSTICS l_row_count = ROW_COUNT;
                    RAISE NOTICE '  Отключено пользователей: %', l_row_count;
                    -- Отключение лицензий
                    PERFORM public.dblink('dbname=ekd_metadata',
                                   'UPDATE license
                                    SET disabled_date=''2020-01-01 00:00:00''
                                    WHERE user_id=''' || l_user_id || '''
                                    AND disabled_date IS NULL                           -- (Добавил АЕГ 27.10.2025)
                                    AND tenant_license_package_id =
                         (SELECT id FROM tenant_license_package WHERE disabled_date IS NULL AND end_date > now())
                    ');
                    RAISE NOTICE '  Отключены лицензии для пользователя';
    
                    -- Отключение неотправленных уведомлений (Перенес в LOOP АЕГ 27.10.2025)
                    UPDATE ekd_notification.email_notification SET skipping = TRUE WHERE user_id = l_user_id;
                    UPDATE ekd_notification.bitrix_notification_task SET skipping = TRUE WHERE user_id = l_user_id;
                    UPDATE ekd_notification.telegram_notification SET skipping = TRUE WHERE user_id = l_user_id;
                    UPDATE ekd_notification.sms_notification SET skipping = TRUE WHERE user_id = l_user_id;
                    -- Отключение PUSH уведомлений (Добавил АЕГ 27.10.2025)
                    UPDATE ekd_notification.push_notification_task SET skipping = TRUE WHERE user_id = l_user_id;
                    RAISE NOTICE '  Отменены неотправленные уведомления';
    
                    RAISE NOTICE '=== Обработка пользователя % завершена ===', l_fio;
    
                END LOOP;
        END
    \$\$;"
}

pre_delete_pdn
