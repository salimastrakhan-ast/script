#!/usr/bin/env bash

# скрипт для расчета MEM_ALLOC'ов контейнеров приложения в зависимости от количества ОЗУ на сервере
# ekd-monolith - 20%
# ekd-file-processing - 25%
# ekd-file - 10%
# ekd-api-gateway, ekd-calendar, ekd-repeat-notification, ekd-chat, ekd-showcase - 5% каждый
# оставшаяся ОЗУ будет занята ekd-postgresql, ekd-kafka, ekd-ui и ОС хоста

TMP_DIR=$(mktemp -d)
PROC_NAME="recalc-mem-alloc-$(date +%Y-%m-%d-%H-%M-%S)"
BACKUP_DIR=".backup/${PROC_NAME}"
LOG_FILE="logs/updates/${PROC_NAME}.txt"

source scripts/util/common.sh
source scripts/util/update_common.sh
source scripts/util/docker_common.sh

set_mem_alloc() {
    var=${1^^}
    value=$2

    sed -i "s/${var}_MEM_ALLOC=.*/${var}_MEM_ALLOC=$value/" "$TMP_DIR/.env"
}

total_memory_mb=$(($(cat /proc/meminfo | grep -i 'memtotal' | grep -o '[[:digit:]]*') / 1024))

new_mem_alloc_monolith=$(($total_memory_mb * 20 / 100))
new_mem_alloc_file=$(($total_memory_mb / 10))
new_mem_alloc_file_proc=$(($total_memory_mb * 25 / 100))
new_mem_alloc_other=$(($total_memory_mb * 5 / 100 ))

pre_update_actions
set_mem_alloc "monolith" $new_mem_alloc_monolith
set_mem_alloc "file" $new_mem_alloc_file
set_mem_alloc "file_processing" $new_mem_alloc_file_proc
set_mem_alloc "api_gateway" $new_mem_alloc_other
set_mem_alloc "calendar" $new_mem_alloc_other
set_mem_alloc "chat" $new_mem_alloc_other
set_mem_alloc "repeat_notification" $new_mem_alloc_other
set_mem_alloc "showcase" $new_mem_alloc_other
set_mem_alloc "news" $new_mem_alloc_other
set_mem_alloc "business_journeys" $new_mem_alloc_other
show_and_apply_changes
restart_app
