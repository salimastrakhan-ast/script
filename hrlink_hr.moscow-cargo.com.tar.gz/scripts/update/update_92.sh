#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="6"

NEW_RELEASE=92
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

source scripts/util/common.sh
source scripts/util/update_common.sh
source scripts/util/docker_common.sh

db_actions() {
    :
}

configs_actions() {
    log "обновление версий контейнеров"

    # если текущий дистро - Astra Linux, ставить образы с постфиксом `-astra`
    MONOLITH_VERSION="$NEW_RELEASE"
    FILE_VERSION="$NEW_RELEASE"
    source /etc/os-release
    if [[ "$ID" == "astra" ]]; then
        MONOLITH_VERSION="$NEW_RELEASE-astra"
        FILE_VERSION="$NEW_RELEASE-astra"
    fi

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$MONOLITH_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$FILE_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    # sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    # переменные окружения для valkey
    echo -e "\nEKD_VALKEY_VERSION=8-alpine\nVALKEY_USERNAME=hrlink\nVALKEY_PASSWORD='$(uuidgen)'" >> "$TMP_DIR/.env"

    # valkey.yaml. по умолчанию выключен
    cat > compose.d/valkey.yaml << EOF
services:
  valkey:
    extends:
      file: ./template.yaml
      service: base
    image: \${DOCKER_NEXUS_LINK:-docker.hr-link.ru}/valkey:\${EKD_VALKEY_VERSION:-8-alpine}
    container_name: valkey
    hostname: valkey
    environment:
      VALKEY_USERNAME: \${VALKEY_USERNAME}
      VALKEY_PASSWORD: \${VALKEY_PASSWORD}
    volumes:
      - ../ekd-config/valkey/valkey.conf:/etc/valkey/valkey.conf
EOF

    docker exec ekd-file mkdir -p /var/hrlink/storage/large_tmp_files
}

post_update() {
    :
}

pre_update_checks
pre_update_actions
configs_actions 2>&1 | tee -a "$LOG_FILE"
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions 2>&1 | tee -a "$LOG_FILE"
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update 2>&1 | tee -a "$LOG_FILE"

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
