#!/bin/bash
set -euo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="2"

NEW_RELEASE=83
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
UPDATE_LOG_FILE="logs/updates/$NEW_RELEASE.txt"

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1"
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1" >> $UPDATE_LOG_FILE
}

pre_update_checks() {
    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    CURR_RELEASE=$(grep EKD_MONOLITH_VERSION .env | cut -d'=' -f2)
    if (( "$NEW_RELEASE" - "$CURR_RELEASE" != 1 )); then
        printf "%b\tПеред установкой релиза %b необходимо установить предыдущие релизы (установленный релиз - %b)%b\n" "$clr_red" "$NEW_RELEASE" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    if (( "$NEW_RELEASE" - "$CURR_RELEASE" == 0 )); then
        printf "%b\tУже установлен релиз %b%b\n" "$clr_red" "$CURR_RELEASE" "$clr_rst"
        exit 1
    fi

    echo "Проверка наличия необходимых пакетов:"

    set +u
    source /etc/os-release
    pkg_not_found=0

    # проверка пакетов по ID и ID_LIKE в /etc/os-release
    if [[ "$ID_LIKE" == *"debian"* ]] || [[ "$ID" == "ubuntu" || "$ID" == "debian" ]]; then
        PKGS=("docker" "bash" "uuid" "ping" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(dpkg --list)
    elif [[ "$ID_LIKE" == *"rhel"* ]] || [[ "$ID" == "fedora" || "$ID" == "rhel" || "$ID" == "centos" ]]; then
        PKGS=("docker" "bash" "util-linux" "iputils" "curl" "wget" "netcat|ncat" "cron" "openssl")
        INSTALLED_PKGS=$(yum list --installed)
    else
        echo 'Тип ОС не установлен. Проверка наличия пакета в $PATH'
        pkgs=("docker" "bash" "uuidgen" "ping" "curl" "wget" "netcat" "cron")

        set +e
        all_pkgs=""

        for dir in $(echo $PATH | tr ':' '\n'); do
            all_pkgs+=$(ls -m $dir 2>/dev/null | sed 's/,/\n/g' | sed 's/ //g')
        done

        for pkg in "${pkgs[@]}"; do
            pkgs=($(echo "$all_pkgs" | sort | grep -v '^$' | uniq))

            if [[ "${pkgs[*]}" =~ "$pkg" ]]; then
                printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
            else
                printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
                pkg_not_found=1
            fi
        done
        set -e
    fi

    for pkg in "${PKGS[@]}"; do
        result=$(echo "$INSTALLED_PKGS" | grep -E "$pkg")
        if [[ "$result" != "" ]]; then
            printf "%b\t%b найден %b\n" "$clr_grn" "$pkg" "$clr_rst"
        else
            printf "%b\t%b не найден! %b\n" "$clr_red" "$pkg" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты перед обновлением! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
    set -u

    # наличие прав на чтение и изменение конфигов
    files=(".env" "docker-compose.yaml" "nginx.conf" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf")
    rw_files_count="${#files[@]}"
    for file in "${files[@]}"; do
        if ! ([[ -w $file ]] && [[ -r $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Невозможно редактирование $file!" "$clr_rst"
            ((rw_files_count--))
        fi
    done

    if [[ $rw_files_count -lt "${#files[@]}" ]]; then
        exit 1
    fi
}

pre_update_actions() {
    mkdir -p "$BACKUP_DIR"
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p "logs/updates"
    touch "$UPDATE_LOG_FILE"

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf "$BACKUP_DIR"
    cp ekd-config/ekd-file/custom.conf "$BACKUP_DIR/ekd-file-custom.conf"
}

db_actions() {
    :
}

configs_actions() {
    log "обновление версий контейнеров"

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$NEW_RELEASE/" .env
    # sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" .env
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" .env

    # добавление template'ов сервисов ekd-news и ekd-buisiness-journeys
    mkdir ./compose.d/
    cat<<EOF > ./compose.d/template.yaml
services:
  base:
    user: root
    logging:
      options:
        max-size: "100m"
        max-file: 3
    restart: on-failure:5
    tty: true
    environment:
      SERVER_API_TOKEN: \${WEB_SERVER_API_TOKEN}
      POSTGRES_HOST: \${POSTGRES_HOST}
      POSTGRES_USERNAME: migrations_user
      POSTGRES_PASSWORD: \${MIGRATIONS_USER_PASSWORD}
      KAFKA_BROKER_URL: \${KAFKA_BROKER_URL}

EOF
    cat<<EOF > ./compose.d/news.yaml
services:
  ekd-news:
    extends:
      file: ./template.yaml
      service: base
    container_name: ekd-news
    hostname: ekd-news
    image: docker.hr-link.ru/ekd/news:\${EKD_NEWS_VERSION}
    environment:
      MEM_ALLOC: \${NEWS_MEM_ALLOC}
      POSTGRES_DBNAME: ekd_news_db
    volumes:
      - ../logs/ekd-news:/var/hrlink/running_instance/news/logs

EOF
    cat<<EOF > ./compose.d/business-journeys.yaml
services:
  ekd-business-journeys:
    extends:
      file: ./template.yaml
      service: base
    container_name: ekd-business-journeys
    hostname: ekd-business-journeys
    image: docker.hr-link.ru/ekd/ekd-business-journeys:\${EKD_BUSINESS_JOURNEYS_VERSION}
    environment:
      MEM_ALLOC: \${BUSINESS_JOURNEYS_MEM_ALLOC}
      POSTGRES_DBNAME: ekd_business_journeys_db
      EKD_ID_SERVER_HOST: http://ekd-monolith:8000
      EKD_SESSION_HOST: http://ekd-monolith:8000
      EKD_METADATA_HOST: http://ekd-monolith:8000
      DB_CONFIG_SECRET_KEY: \${DB_SECRET_KEY}
      EKD_ID_SERVER_API_TOKEN: Configured \${WEB_SERVER_API_TOKEN}
      EKD_SESSION_API_TOKEN: \${WEB_SERVER_API_TOKEN}
      EKD_METADATA_API_TOKEN: \${WEB_SERVER_API_TOKEN}
      SERVER_API_TOKEN_VALUE: \${WEB_SERVER_API_TOKEN}
      GANDALF_HOST: https://esa.hr-link.ru
      GANDALF_API_TOKEN: \${LICENSE_MANAGER_TOKEN}
    volumes:
      - ../logs/ekd-business-journeys:/var/hrlink/running_instance/ekd-business-journeys/logs

EOF
} >> $UPDATE_LOG_FILE 2>&1

pull_images() {
    log "Удаляем старые образы"
    docker system prune -af --filter "until=$((24*5))h" | grep "Total reclaimed space:"
    log "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
}

restart_app() {
    read -p "Перезапустить приложение? [y/N]: " -r
    echo
    if [[ $REPLY =~ ^[YyНн]$ ]]; then
        docker compose up -d || docker-compose up -d
    else
        echo "Перезапуск отменен"
    fi
}

status_check() {
    log "Ожидание поднятия приложения..."
    containers=($(docker ps --format {{.Names}} | grep 'ekd' | grep -v -E 'charon|ui'))
    declare -A up_containers

    time_counter=0
    set +u
    set +e
    while [[ ${#up_containers[@]} -lt ${#containers[@]} ]]; do
        if [[ $time_counter -gt 20 ]]; then
            printf "%b%s%b\n" "$clr_red" "timeout" "$clr_rst"
            break
        fi
        
        for container in "${containers[@]}"; do
            if [[ -n ${up_containers[$container]} ]]; then
                continue
            fi

            status=$(docker inspect "$container" --format '{{.State.Health.Status}}' 2>/dev/null)

            if [[ "$status" == "healthy" ]]; then
                up_containers[$container]=1
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi

            if [[ "$status" == "unhealthy" ]] && [[ ${up_containers["ekd-monolith"]} -eq 1 ]]; then
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi
        done
        
        ((time_counter++))
        sleep 15
    done
    set -e
    set -u

    ui_ver=$(docker exec -it ekd-ui curl localhost:80/assets/json/version.json | grep -o '"version": *"[^"]*' | cut -d '"' -f 4 | cut -d '.' -f 2)
    if [[ "$ui_ver" == "$NEW_RELEASE" ]]; then
        printf "\t%b%s%b\n" "$clr_grn" "ekd-ui healthy!" "$clr_rst"
    fi
    
    log "Приложение встало!"
}

post_update() {
    if [[ -n "$(docker container ls --format 'table {{.Names}}' 2>/dev/null | grep 'ekd-postgresql')" ]]; then
        is_db_merged=$(docker exec ekd-postgresql psql -U postgres --dbname ekd_metadata -A -t -c "select distinct db_merged from tenant_database_connection")
        if [[ $is_db_merged != "t" ]]; then
            printf "\n%bБД не схлопнута! Обратитесь в поддержку для выполнения схлопывания БД! %b\n" "$clr_red" "$clr_rst"
        fi
    fi
}

pre_update_checks
pre_update_actions
db_actions
configs_actions
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
