#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="3"

NEW_RELEASE=94
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d:%H-%M-%S)"
LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

source scripts/util/common.sh
source scripts/util/update_common.sh
source scripts/util/docker_common.sh

db_actions() {
    :
}

configs_actions() {
    log "обновление версий контейнеров"

    # если текущий дистро - Astra Linux, ставить образы с постфиксом `-astra`
    MONOLITH_VERSION="$NEW_RELEASE"
    FILE_VERSION="$NEW_RELEASE"
    source /etc/os-release
    if [[ "$ID" == "astra" ]]; then
        MONOLITH_VERSION="$NEW_RELEASE-astra"
        FILE_VERSION="$NEW_RELEASE-astra"
    fi

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$MONOLITH_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$FILE_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    # sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    # директория для нового механизма архивации данных БД
    docker exec ekd-file mkdir -p /var/hrlink/storage/hr-link-db-archives || mkdir ./ekd-monolith-storage/hr-link-db-archives
    if [[ -d ./postgresql-data/pgdata/hr-link-archives ]]; then
        mv ./postgresql-data/pgdata/hr-link-archives ./ekd-monolith-storage/hr-link-db-archives/
    fi
    sed -i '/ekd-monolith\/logs/a\      - ./ekd-monolith-storage/hr-link-db-archives/:/var/hrlink/storage/hr-link-db-archives/:rw,z' "$TMP_DIR/docker-compose.yaml"
    sed -i '/ekd-file\/logs/a\      - ./ekd-monolith-storage/hr-link-db-archives/:/var/hrlink/storage/hr-link-db-archives/:rw,z' "$TMP_DIR/docker-compose.yaml"

    # конвертация play.filters.cors.allowedOrigins = [ ... ] в строки с +=. Необходимо для того чтобы дефолтные значения не терялись
    output=$(mktemp)

    while IFS= read -r line; do
        if [[ $line =~ ^play\.filters\.cors\.allowedOrigins[[:space:]]*=[[:space:]]*\[(.*)\] ]]; then
            inside=${BASH_REMATCH[1]}
            IFS=',' read -ra domains <<< "$inside"
            for d in "${domains[@]}"; do
                d=$(echo "$d" | sed -E 's/^[[:space:]]*|"|[[:space:]]*$//g')
                printf 'play.filters.cors.allowedOrigins += "%s"\n' "$d" >> "$output"
            done
        else
            printf "%s\n" "$line" >> "$output"
        fi
    done < "${TMP_DIR}/ekd-config/custom.conf"
    mv "$output" "${TMP_DIR}/ekd-config/custom.conf"
}

post_update() {
    :
}

pre_update_checks
pre_update_actions
configs_actions 2>&1 | tee -a "$LOG_FILE"
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions 2>&1 | tee -a "$LOG_FILE"
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update 2>&1 | tee -a "$LOG_FILE"

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
