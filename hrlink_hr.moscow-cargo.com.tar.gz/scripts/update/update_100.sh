#!/usr/bin/env bash
set -Eeuo pipefail
IFS=$'\n\t'

SCRIPT_VERSION="3"

NEW_RELEASE=100
BACKUP_DIR=".backup/before_upd_$NEW_RELEASE-$(date +%Y-%m-%d-%H-%M-%S)"
LOG_FILE="logs/updates/$NEW_RELEASE.txt"
TMP_DIR=$(mktemp -d)

source scripts/util/common.sh
source scripts/util/update_common.sh
source scripts/util/docker_common.sh

local_pre_update_checks() {
    pre_update_checks
}

db_actions() {
    :
}

configs_actions() {
    log "обновление версий контейнеров"

    # если текущий дистро - Astra Linux, ставить образы с постфиксом `-astra`
    MONOLITH_VERSION="$NEW_RELEASE"
    FILE_VERSION="$NEW_RELEASE"
    source /etc/os-release
    if [[ "$ID" == "astra" ]]; then
        MONOLITH_VERSION="$NEW_RELEASE-astra"
        FILE_VERSION="$NEW_RELEASE-astra"
    fi

    # обновление версий контейнеров
    sed -i "s/EKD_UI_VERSION=.*/EKD_UI_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_MONOLITH_VERSION=.*/EKD_MONOLITH_VERSION=$MONOLITH_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_VERSION=.*/EKD_FILE_VERSION=$FILE_VERSION/" "$TMP_DIR/.env"
    sed -i "s/EKD_FILE_PROCESSING_VERSION=.*/EKD_FILE_PROCESSING_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_API_GATEWAY_VERSION=.*/EKD_API_GATEWAY_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_REPEAT_NOTIFICATION_VERSION=.*/EKD_REPEAT_NOTIFICATION_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CALENDAR_VERSION=.*/EKD_CALENDAR_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_CHAT_VERSION=.*/EKD_CHAT_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_SHOWCASE_VERSION=.*/EKD_SHOWCASE_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_NEWS_VERSION=.*/EKD_NEWS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"
    sed -i "s/EKD_BUSINESS_JOURNEYS_VERSION=.*/EKD_BUSINESS_JOURNEYS_VERSION=$NEW_RELEASE/" "$TMP_DIR/.env"

    if ! grep -q 'ekd.ui.configuration.metrics.yandex.enabled = false' "$TMP_DIR/ekd-config/custom.conf"; then
        echo -e "ekd.ui.configuration.metrics.yandex.enabled = false" >> "$TMP_DIR/ekd-config/custom.conf"
    fi
    if ! grep -q 'daemons.telegramConfirmedInvitationStatusSync.enabled = true' "$TMP_DIR/ekd-config/custom.conf"; then
        echo -e "daemons.telegramConfirmedInvitationStatusSync.enabled = true" >> "$TMP_DIR/ekd-config/custom.conf"
    fi
    sed -i 's/CLIENT_DOMAIN/INSTANCE_DOMAIN/g' "$TMP_DIR/ekd-config/custom.conf"

    if [[ -f "$TMP_DIR/compose.d/monitoring.yaml" ]]; then
        sed -i 's/space/ekd/' "$TMP_DIR/compose.d/monitoring.yaml"
    fi

    # реструктуризация якорей в docker-compose.yaml
    awk '
    BEGIN { in_base=0; in_mono=0; in_fp=0; svc=""; saw_valkey=0 }

    # ── якорь x-base-env → x-db-conn + x-common-env ────────────────────────
    /^x-base-env: &base-env$/ {
        print "x-db-conn: &db-conn"
        print "    POSTGRES_USERNAME: '"'"'migrations_user'"'"'"
        print "    POSTGRES_PASSWORD: ${MIGRATIONS_USER_PASSWORD}"
        print "    POSTGRES_HOST: ${POSTGRES_HOST}:${POSTGRES_PORT}"
        print ""
        print "x-common-env: &common-env"
        print "    WEB_SERVER_API_TOKEN: ${WEB_SERVER_API_TOKEN}"
        print "    SERVER_API_TOKEN: ${WEB_SERVER_API_TOKEN}"
        print "    HTTP_SECRET: ${HTTP_SECRET}"
        in_base=1; next
    }
    # пустая строка завершает блок x-base-env (сохраняем её)
    in_base && /^$/ { in_base=0; print; next }
    in_base          { next }

    # ── расширение x-monolith-env ────────────────────────────────────────────
    /^x-monolith-env: &monolith-env$/ { in_mono=1 }

    in_mono && /^    MEM_ALLOC: \$\{MONOLITH_MEM_ALLOC\}$/ {
        print
        print "    INSTANCE_DOMAIN: ${CLIENT_DOMAIN}"
        print "    ALLOWED_HOST: ${ALLOWED_HOST}"
        print "    AVAILABLE_HOST: ${AVAILABLE_HOST}"
        next
    }
    in_mono && /^    SHARED_FILE_API_TOKEN: / {
        print
        print "    LICENSE_MANAGER_TOKEN: ${LICENSE_MANAGER_TOKEN}"
        next
    }
    in_mono && /^    VALKEY_USERNAME: / { saw_valkey=1 }
    in_mono && /^    VALKEY_PASSWORD: / {
        print
        print "    STORAGE_ENCRYPTION_AES256_KEY: ${STORAGE_ENCRYPTION_AES256_KEY}"
        print "    TRANSFER_ENCRYPTION_AES256_KEY: ${TRANSFER_ENCRYPTION_AES256_KEY}"
        print "    KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
        print "    DB_SECRET_KEY: ${DB_SECRET_KEY}"
        print "    TENANT_REGISTRATION_DB_HOST: ${POSTGRES_HOST}"
        print "    TENANT_REGISTRATION_DB_PORT: ${POSTGRES_PORT}"
        in_mono=0; next
    }
    # если VALKEY_USERNAME/VALKEY_PASSWORD отсутствуют — добавляем их при закрытии блока
    in_mono && /^$/ {
        if (!saw_valkey) {
            print "    VALKEY_USERNAME: ${VALKEY_USERNAME:-none}"
            print "    VALKEY_PASSWORD: ${VALKEY_PASSWORD:-none}"
            print "    STORAGE_ENCRYPTION_AES256_KEY: ${STORAGE_ENCRYPTION_AES256_KEY}"
            print "    TRANSFER_ENCRYPTION_AES256_KEY: ${TRANSFER_ENCRYPTION_AES256_KEY}"
            print "    KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
            print "    DB_SECRET_KEY: ${DB_SECRET_KEY}"
            print "    TENANT_REGISTRATION_DB_HOST: ${POSTGRES_HOST}"
            print "    TENANT_REGISTRATION_DB_PORT: ${POSTGRES_PORT}"
        }
        in_mono=0; saw_valkey=0; print; next
    }

    # ── добавление KAFKA_BROKER_URL в x-file-proc-env ───────────────────────
    /^x-file-proc-env:/  { in_fp=1 }
    in_fp && /^    EKD_METADATA_API_TOKEN: / {
        print
        print "    KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
        in_fp=0; next
    }

    # ── отслеживание текущего сервиса ────────────────────────────────────────
    /^  ekd-file:$/                { svc="ekd-file" }
    /^  ekd-file-processing:$/     { svc="ekd-file-processing" }
    /^  ekd-api-gateway:$/         { svc="ekd-api-gateway" }
    /^  postgresql:$/              { svc="postgresql" }
    /^  ekd-calendar:$/            { svc="ekd-calendar" }
    /^  ekd-chat:$/                { svc="ekd-chat" }
    /^  ekd-repeat-notification:$/ { svc="ekd-repeat-notification" }
    /^  ekd-showcase:$/            { svc="ekd-showcase" }
    /^  ekd-charon:$/              { svc="ekd-charon" }
    /^  ekd-service-checker:$/     { svc="ekd-service-checker" }

    # ── замена составных ссылок на анкоры (уникальные) ──────────────────────
    /^ +<<: \[ \*base-env, \*monolith-env \]$/ {
        print "      <<: [ *common-env, *db-conn, *monolith-env ]"; next
    }
    /^ +<<: \[ \*base-env, \*file-processing-env \]$/ {
        print "      <<: [ *common-env, *db-conn, *file-processing-env ]"; next
    }

    # ── контекстно-зависимая замена <<: *base-env в сервисах ─────────────────
    /^      <<: \*base-env$/ {
        if (svc == "postgresql") {
            next
        } else if (svc == "ekd-api-gateway") {
            print "      <<: [ *common-env ]"
            print "      KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
        } else if (svc == "ekd-repeat-notification" || svc == "ekd-service-checker") {
            print "      <<: [ *common-env, *db-conn ]"
            print "      KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
        } else {
            print "      <<: [ *common-env, *db-conn ]"
        }
        next
    }

    # ── дополнительные переменные для отдельных сервисов ────────────────────

    # postgresql: добавление POSTGRES_DB после PGDATA
    svc == "postgresql" && /^      PGDATA: / {
        print
        print "      POSTGRES_DB: ${POSTGRES_DB}"
        next
    }

    # ekd-file: 7 переменных из бывшего x-base-env
    svc == "ekd-file" && /^      EKD_METADATA_API_TOKEN: / {
        print
        print "      ALLOWED_HOST: ${ALLOWED_HOST}"
        print "      STORAGE_ENCRYPTION_AES256_KEY: ${STORAGE_ENCRYPTION_AES256_KEY}"
        print "      TRANSFER_ENCRYPTION_AES256_KEY: ${TRANSFER_ENCRYPTION_AES256_KEY}"
        print "      KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
        print "      DB_SECRET_KEY: ${DB_SECRET_KEY}"
        print "      TENANT_REGISTRATION_DB_HOST: ${POSTGRES_HOST}"
        print "      TENANT_REGISTRATION_DB_PORT: ${POSTGRES_PORT}"
        next
    }

    # ekd-calendar: LICENSE_MANAGER_TOKEN
    svc == "ekd-calendar" && /^      EKD_CALENDAR_API_TOKEN: / {
        print
        print "      LICENSE_MANAGER_TOKEN: ${LICENSE_MANAGER_TOKEN}"
        next
    }

    # ekd-showcase: KAFKA_BROKER_URL в конце environment
    svc == "ekd-showcase" && /^      EKD_METADATA_API_TOKEN: / {
        print
        print "      KAFKA_BROKER_URL: ${KAFKA_BROKER_URL}"
        next
    }

    { print }
    ' "$TMP_DIR/docker-compose.yaml" > "$TMP_DIR/docker-compose.yaml.tmp"
    mv "$TMP_DIR/docker-compose.yaml.tmp" "$TMP_DIR/docker-compose.yaml"

    # обновление ssl_ciphers в nginx.conf
    sed -i 's|ssl_ciphers "ECDH+AESGCM:DH+AESGCM:ECDH+AES256:DH+AES256:ECDH+AES128:DH+AES:ECDH+3DES:DH+3DES:RSA+AESGCM:RSA+AES:RSA+3DES:!aNULL:!MD5:!DSS:!AES256";|ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384:DHE-RSA-CHACHA20-POLY1305;|' "$TMP_DIR/nginx.conf"
}

post_update() {
    :
}

local_pre_update_checks
pre_update_actions
configs_actions 2>&1 | tee -a "$LOG_FILE"
show_and_apply_changes
set +u
if [[ -z "$1" ]]; then
    pull_images
    restart_app
    db_actions 2>&1 | tee -a "$LOG_FILE"
    status_check
else
    printf "\n%bЗагрузка образов и перезапуск приложения пропущены.%b\n" "$clr_ylw" "$clr_rst"
fi
set -u
post_update 2>&1 | tee -a "$LOG_FILE"

printf "\n%bГотово%b\n" "$clr_grn" "$clr_rst"
