#!/usr/bin/env bash

# скрипт, содержащий частые функции скриптов
# для использования функций этого скрипта нужно добавить следующую строку в скрипт
#   source scripts/util/common.sh
# ВАЖНО: следующие переменные должны быть заданы в исходном скрипте для корректного функционирования данных функций
#   LOG_FILE

UTIL_COMMON_VERSION="1"

# trap 'echo "ERROR at ${BASH_SOURCE}:${LINENO} in ${FUNCNAME[0]}" >&2' ERR

clr_rst='\033[0m'
clr_red='\033[1;31m'
clr_grn='\033[1;32m'
clr_ylw='\033[1;33m'

log() {
    echo "$(date +%Y-%m-%d:%H-%M-%S) $1"

    if [[ -n "${LOG_FILE}" ]]; then
        echo "$(date +%Y-%m-%d:%H-%M-%S) $1" >> $LOG_FILE
    fi
}

warn() {
    msg=$1
    printf "\n%b${msg}%b\n" "$clr_ylw" "$clr_rst"
}

err() {
    msg=$1
    printf "\n%b${msg}%b\n" "$clr_red" "$clr_rst"
}