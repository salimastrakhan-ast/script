#!/usr/bin/env bash

# скрипт, содержащий частые функции скриптов
# для использования функций этого скрипта нужно добавить следующую строку в скрипт
#   source scripts/util/update_common.sh
# ВАЖНО: следующие переменные должны быть заданы в исходном скрипте для корректного функционирования данных функций
#   BACKUP_DIR
#   TMP_DIR
#   LOG_FILE

UTIL_UPDATE_COMMON_VERSION="7"

pre_update_checks() {
    # проверка сервера на
    #   - соответствие минимальным требованиям
    #   - наличие свободного места
    # проверка деплоя приложения на частые кастомизации

    ls docker-compose.yaml .env > /dev/null 2>&1 || { echo "скрипт необходимо запустить из директории с docker-compose.yaml и .env"; exit 4; }

    if [[ -n "$NEW_RELEASE" ]]; then
        CURR_RELEASE=$(grep EKD_MONOLITH_VERSION .env | cut -d'=' -f2 | cut -d'-' -f1)
        if (( "$NEW_RELEASE" - "$CURR_RELEASE" > 1 )); then
            printf "%b\tПеред установкой релиза %b необходимо установить предыдущие релизы (установленный релиз - %b)%b\n" "$clr_red" "$NEW_RELEASE" "$CURR_RELEASE" "$clr_rst"
            exit 1
        fi

        if (( "$NEW_RELEASE" - "$CURR_RELEASE" == 0 )); then
            printf "%b\tУже установлен релиз %b%b\n" "$clr_red" "$CURR_RELEASE" "$clr_rst"
            exit 1
        fi

        if (( "$NEW_RELEASE" - "$CURR_RELEASE" < 0 )); then
            printf "%b\tУстановка старого релиза невозможна! Установлен релиз %b%b\n" "$clr_red" "$CURR_RELEASE" "$clr_rst"
            exit 1
        fi
    fi

    echo "Проверка наличия необходимых пакетов:"
    set +u
    if [[ -z "${TEST:-}" ]]; then
        source scripts/setup/check_requirements.sh
        package_requirements
    fi
    set -u

    # наличие свободного места
    disks=("/" "/var")
    echo
    for disk in "${disks[@]}"; do
        disk_space=$(df $disk --output=avail -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
        if [[ $disk_space -lt 10 ]]; then
            printf "\t%bНа $disk недостаточно места ($disk_space). Для обновления необходимо 10ГБ.%b\n" "$clr_red" "$disk_space" "$clr_rst"
        else
            printf "\t%b$disk\tOK (%d GB free) %b\n" "$clr_grn" "$disk_space" "$clr_rst"
        fi
    done

    # Размещение файлов приложения в разделе жесткого диска, зарезервированного под ОС.
    if [[ "$(stat -c %d .)" -eq "$(stat -c %d /)" ]]; then
        printf "%b\tДиректория приложения расположена на диске с ОС!%b\n" "$clr_red" "$clr_rst"
    fi

    # Вынесение любого сервиса на отдельный сервер
    compose_config=($(docker compose config --services || docker-compose config --services ))
    all_services=("ekd-file-processing" "ekd-monolith" "ekd-showcase" "ekd-ui" "ekd_kafka" "postgresql" "ekd-api-gateway" "ekd-calendar" "ekd-charon" "ekd-chat" "ekd-file" "ekd-repeat-notification")

    set +u
    declare -A lookup
    for item in "${compose_config[@]}"; do
        lookup["$item"]=1
    done

    for item in "${all_services[@]}"; do
        if [[ -z "${lookup[$item]}" ]]; then
            printf "\t%b%b%b\n" "$clr_red" "На сервере не найден контейнер $item!" "$clr_rst"
        fi
    done
    set -u

    # конфиги/сторадж/т.д. в другой директории или их нельзя читать и редактировать
    files=(".env" "docker-compose.yaml" "nginx.conf" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf")
    rw_files_count="${#files[@]}"
    missing_files_count=0
    for file in "${files[@]}"; do
        if ! ([[ -f $file ]] || [[ -d $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Не найден $file в директории приложения!" "$clr_rst"
            ((missing_files_count++))
        elif ! ([[ -w $file ]] || [[ -r $file ]]); then
            printf "\t%b%b%b\n" "$clr_red" "Невозможно чтение или редактирование $file!" "$clr_rst"
            ((rw_files_count--))
        fi
    done
    if [[ $missing_files_count -gt 0 ]] || [[ $rw_files_count -lt "${#files[@]}" ]] && [[ -z "${TEST:-}" ]]; then
        exit 1
    fi

    # SMTP & SMS-шлюз
    if [[ "$(grep 'play.mailer' ekd-config/custom.conf)" != "" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "Настроена отправка email на свой SMTP-сервер!" "$clr_rst"
    fi
    if [[ "$(grep 'notification.tenants.clientGateSender' ekd-config/custom.conf)" != "" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "Настроена отправка SMS на свой SMS-шлюз!" "$clr_rst"
    fi

    # терминация SSL не в ekd-ui
    if [[ $(grep -E '^\s*[^#]*443 ssl' nginx.conf) == "" ]]; then
        printf "\t%b%b%b\n" "$clr_ylw" "Терминирование SSL происходит не в ekd-ui!" "$clr_rst"
    fi

    # аутентифицирован ли текущий пользователь в docker registry
    DOCKER_REGISTRY_URL=$(grep -E '^DOCKER_REGISTRY_URL=' .env | cut -d'=' -f2-) || true
    DOCKER_NEXUS_LINK=$(grep -E '^DOCKER_NEXUS_LINK=' .env | cut -d'=' -f2-) || true
    REGISTRY_LINK="${DOCKER_REGISTRY_URL:-$DOCKER_NEXUS_LINK}"
    REGISTRY_LINK="${REGISTRY_LINK:-docker.hr-link.ru}"
    DOMAIN="${REGISTRY_LINK%%/*}"
    not_auth=0
    if ! grep -q "\"$DOMAIN\"" "$HOME/.docker/config.json" 2>/dev/null; then
        printf "\t%bТекущий пользователь (%s) не аутентифицирован в Docker Registry (%s)%b\n" "$clr_red" "$(whoami)" "$DOMAIN" "$clr_rst"
        not_auth=1
    fi

    if [[ $not_auth == 1 ]] && [[ "$DOMAIN" == "docker.hr-link.ru" ]] && [[ -z "${TEST:-}" ]]; then
        exit 1
    fi
}

pre_update_actions() {
    # создает бекапы конфигов приложения и временные копии конфигов для изменений скриптами
    mkdir -p "$BACKUP_DIR"
    echo "Директория бекапа до обновления - $BACKUP_DIR"
    mkdir -p "logs/updates"
    touch "$LOG_FILE"

    mkdir -p "$TMP_DIR/ekd-config/ekd-file/"
    mkdir -p "$TMP_DIR/compose.d/"

    cp docker-compose.yaml nginx.conf .env ekd-config/custom.conf "$BACKUP_DIR"
    cp ekd-config/ekd-file/custom.conf "$BACKUP_DIR/ekd-file-custom.conf"

    cp .env docker-compose.yaml nginx.conf "$TMP_DIR"
    cp compose.d/*.yaml "$TMP_DIR/compose.d/"
    cp ekd-config/custom.conf "$TMP_DIR/ekd-config/custom.conf"
    cp ekd-config/ekd-file/custom.conf "$TMP_DIR/ekd-config/ekd-file/custom.conf"
}

show_and_apply_changes() {
    # показывает diff конфигов до/после изменений в скриптах.
    # если изменения устраивают пользователя копирует их в директорию приложения и перезапускает его
    files=(".env" "docker-compose.yaml" "ekd-config/custom.conf" "ekd-config/ekd-file/custom.conf" "compose.d/news.yaml" "compose.d/business-journeys.yaml" "nginx.conf")
    set +eu
    for file in "${files[@]}"; do
        out=$(diff -C 3 $file "$TMP_DIR/$file")
        if [[ "$out" != "" ]]; then
            printf "%b%s%b\n" "$clr_ylw" "diff изменений в $file" "$clr_rst"
            log "$out"
            printf "$clr_grn"
            read -p "Нажмите Enter чтобы продолжить"
            printf "$clr_rst"
        fi
    done
    set -eu

    if [[ -n "${AUTOMATED_UPDATE:-}" ]]; then
        cp -r "$TMP_DIR/." .
        return 0
    fi

    while true; do
        read -rp "Применить изменения? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                cp -r "$TMP_DIR/." .
                break
                ;;
            [Nn]|"")
                echo "Обновление отменено"
                exit 1
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}
