#!/usr/bin/env bash

# скрипт, содержащий частые функции скриптов для работы с docker
# для использования функций этого скрипта нужно добавить следующие строки в скрипт
#   source scripts/util/common.sh
#   source scripts/util/docker_common.sh
# ВАЖНО: следующие переменные должны быть заданы в исходном скрипте для корректного функционирования данных функций
#   LOG_FILE

UTIL_DOCKER_COMMON_VERSION="2"

pull_images() {
    log "Удаляем старые образы"
    docker system prune -af --filter "until=$((24*5))h" | grep "Total reclaimed space:" || true
    log "Cкачиваем новые образы приложения"
    docker compose pull || docker-compose pull
}

restart_app() {
    if [[ -n "${AUTOMATED_UPDATE:-}" ]]; then
        docker compose up -d || docker-compose up -d
        return 0
    fi

    while true; do
        read -rp "Перезапустить приложение? [y/N]: " reply
        echo
        case "$reply" in
            [Yy])
                docker compose up -d || docker-compose up -d
                break
                ;;
            [Nn]|"")
                echo "Перезапуск отменен"
                printf "\t%b%b%b\n" "$clr_red" "Приложение не запущено!" "$clr_rst"
                break
                ;;
            *)
                echo "Введите y (yes) или n (no)"
                ;;
        esac
    done
}

status_check() {
    if [[ -n "${TEST:-}"  ]]; then
        return 0
    fi

    log "Ожидание поднятия приложения..."
    containers=($(docker ps --format {{.Names}} | grep 'ekd' | grep -v -E 'charon|ui'))
    declare -A up_containers

    time_counter=0
    set +u
    set +e
    while [[ ${#up_containers[@]} -lt ${#containers[@]} ]]; do
        if [[ $time_counter -gt 20 ]]; then
            printf "%b%s%b\n" "$clr_red" "timeout" "$clr_rst"
            break
        fi

        for container in "${containers[@]}"; do
            if [[ -n ${up_containers[$container]} ]]; then
                continue
            fi

            status=$(docker inspect "$container" --format '{{.State.Health.Status}}' 2>/dev/null)

            if [[ "$status" == "healthy" ]]; then
                up_containers[$container]=1
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi

            if [[ "$status" == "unhealthy" ]] && [[ ${up_containers["ekd-monolith"]} -eq 1 ]]; then
                printf "\t%b%s%b\n" "$clr_grn" "$container $status!" "$clr_rst"
            fi
        done

        ((time_counter++))
        sleep 15
    done
    set -e
    set -u

    if [[ -n "$NEW_RELEASE" ]]; then
        ui_ver=$(docker exec -it ekd-ui curl localhost:80/assets/json/version.json | grep -o '"version": *"[^"]*' | cut -d '"' -f 4 | cut -d '.' -f 2)
        if [[ "$ui_ver" == "$NEW_RELEASE" ]]; then
            printf "\t%b%s%b\n" "$clr_grn" "ekd-ui healthy!" "$clr_rst"
        fi
    fi

    log "Приложение встало!"
}
