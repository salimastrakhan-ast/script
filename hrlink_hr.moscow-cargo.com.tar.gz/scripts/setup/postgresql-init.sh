#!/bin/bash
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USERNAME" --dbname "$POSTGRES_DB" <<-EOSQL
    CREATE USER migrations_user WITH LOGIN SUPERUSER PASSWORD '$MIGRATIONS_USER_PASSWORD';

    CREATE DATABASE ekd_ca OWNER migrations_user;
    CREATE DATABASE ekd_id OWNER migrations_user;
    CREATE DATABASE ekd_ekd OWNER migrations_user;
    CREATE DATABASE ekd_session OWNER migrations_user;
    CREATE DATABASE ekd_metadata OWNER migrations_user;
    CREATE DATABASE ekd_file OWNER migrations_user;
    CREATE DATABASE ekd_request_logger OWNER migrations_user;
    CREATE DATABASE ekd_notification OWNER migrations_user;

    CREATE DATABASE ekd_calendar_db OWNER migrations_user;
    CREATE DATABASE ekd_chat_db OWNER migrations_user;
    CREATE DATABASE ekd_repeat_notification_db OWNER migrations_user;
    CREATE DATABASE ekd_showcase_db OWNER migrations_user;
    CREATE DATABASE ekd_file_processing_db OWNER migrations_user;

    CREATE DATABASE ekd_news_db OWNER migrations_user;
    CREATE DATABASE ekd_business_journeys_db OWNER migrations_user;
EOSQL

psql --username "$POSTGRES_USERNAME" --dbname "$POSTGRES_DB" -c "ALTER SYSTEM SET max_connections = 1000;"
psql --username "$POSTGRES_USERNAME" --dbname "$POSTGRES_DB" -c "ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements';"

pg_ctl -D /var/lib/postgresql/data/pgdata restart

psql --username "$POSTGRES_USERNAME" --dbname "$POSTGRES_DB" -c "CREATE EXTENSION IF NOT EXISTS pg_stat_statements;"
psql --username "$POSTGRES_USERNAME" --dbname "$POSTGRES_DB" -c "SELECT pg_reload_conf();"
