#!/bin/bash

hardware_requirements() {
    # проверка соответствию минимальным требованиям по железу
    min_cpu_cores=8
    min_mem_gbs=12
    min_disk_space=256

    cpu=$(nproc)
    if [[ $cpu -lt $min_cpu_cores ]]; then
        printf '%bНа сервере недостаточно ядер CPU (%d, минимум - %d)%b\n' "$clr_red" "$cpu" "$min_cpu_cores" "$clr_rst"
        hw_err=1
    else
        printf '%bCPU OK (%d)%b\n' "$clr_grn" "$cpu" "$clr_rst"
    fi

    mem=$(free -m | awk '/^Mem:/ {printf "%.0f", $2/1024}')
    if [[ $mem -lt $min_mem_gbs ]]; then
        printf '%bНа сервере недостаточно GB ОЗУ (%d gb, минимум - %d gb)%b\n' "$clr_red" "$mem" "$min_mem_gbs" "$clr_rst"
        hw_err=1
    else
        printf '%bMEM OK (%d gb)%b\n' "$clr_grn" "$mem" "$clr_rst"
    fi

    disk_space=$(df --total --output=size -x loop -x tmpfs | tail -n 1 | awk '{print int($1 / 1024 / 1024)}')
    if [[ $disk_space -lt $min_disk_space ]]; then
        printf '%bНа сервере недостаточно места на диске (%d gb, минимум - %d gb)%b\n' "$clr_red" "$disk_space" "$min_disk_space" "$clr_rst"
        hw_err=1
    else
        printf '%bDISK OK (%d gb) %b\n' "$clr_grn" "$disk_space" "$clr_rst"
    fi

    if ! [[ $hw_err -eq 0 ]] && ! [[ $ignore_errors -eq 0 ]]; then
        exit 1
    fi
}

permission_requirements() {
    # проверка прав текущего пользователя
    if [[ $(id -u) -eq 0 || $(id -nG) =~ (^|[[:space:]])docker($|[[:space:]]) ]]; then 
        printf '%bТекущий пользователь имеет доступ к docker%b\n' "$clr_grn" "$clr_rst"
    else
        printf '%bТекущий пользователь не имеет доступ к docker%b\n' "$clr_red" "$clr_rst"
        exit 1
    fi

    if [ ! -w . ]; then
        printf '%bТекущий пользователь не имеет права изменять директорию приложения%b\n' "$clr_red" "$clr_rst"
        exit 1
    else
        printf '%bТекущий пользователь имеет права изменять директорию приложения%b\n' "$clr_grn" "$clr_rst"
    fi
}

package_requirements() {
    # проверка наличия необходимых пакетов в системе
    REQUIRED_COMMANDS=("docker" "bash" "uuidgen" "ping" "curl" "wget" "openssl" "crontab")

    # текстовый редактор
    if command -v vim >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("vim")
    elif command -v nano >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("nano")
    else
        REQUIRED_COMMANDS+=("vim")
    fi

    # ss/netstat
    if command -v ss >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("ss")
    elif command -v netstat >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("netstat")
    else
        REQUIRED_COMMANDS+=("ss")
    fi

    # netcat (может называться nc, netcat или ncat)
    if command -v nc >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("nc")
    elif command -v netcat >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("netcat")
    elif command -v ncat >/dev/null 2>&1; then
        REQUIRED_COMMANDS+=("ncat")
    else
        REQUIRED_COMMANDS+=("netcat")
    fi

    pkg_not_found=0

    for cmd in "${REQUIRED_COMMANDS[@]}"; do
        if command -v "$cmd" >/dev/null 2>&1; then
            printf "%b\t%-10s найден %b\n" "$clr_grn" "$cmd" "$clr_rst"
        else
            printf "%b\t%-10s не найден! %b\n" "$clr_red" "$cmd" "$clr_rst"
            pkg_not_found=1
        fi
    done

    if [[ "$pkg_not_found" -gt 0 ]]; then
        printf "%bНеобходимо установить необходимые пакеты! %b\n" "$clr_red" "$clr_rst"
        exit 1
    fi
}

docker_version_requirements() {
    # проверка версий docker и docker compose
    docker_engine_min_version=23
    compose_supported_major_version=2
    compose_supported_minor_version=24

    echo "Версии docker:"
    docker_version=$(docker version --format '{{.Server.Version}}')
    docker_major_version=$(echo "$docker_version" | cut -d '.' -f 1)

    if [[ $docker_major_version -lt $docker_engine_min_version ]]; then
        printf "$clr_red\tВерсия docker ($docker_version) меньше минимальной ($min_docker_version) $clr_rst\n"
        exit 1
    else
        printf "$clr_grn\tВерсия docker ($docker_version) ОК$clr_rst\n"
    fi

    compose_version=$(docker compose version 2>/dev/null | awk '{print $4}' | cut -d',' -f1 | sed 's/v//')
    if [[ "$compose_version" != "" ]]; then
        compose_major_version=$(echo "$compose_version" | cut -d '.' -f 1)
        compose_minor_version=$(echo "$compose_version" | cut -d '.' -f 2)
        unsupported=0

        if [[ "$compose_major_version" -lt "$compose_supported_major_version" ]]; then
            unsupported=1
        fi
        if [[ "$compose_major_version" -eq "$compose_supported_major_version" ]] && [[ "$compose_minor_version" -lt "$compose_supported_minor_version" ]]; then
            unsupported=1
        fi

        if [[ "$unsupported" -eq 1 ]]; then
            printf "$clr_red\tВерсия docker compose (%d) меньше минимальной (%d.%d.0) $clr_rst\n" "$compose_version" "$compose_supported_major_version" "$compose_supported_minor_version"
        else
            printf "$clr_grn\tВерсия docker compose ($compose_version) ОК$clr_rst\n"
        fi
    fi
}

cloud_connectivity_requirements() {
    # проверка доступности облачных микросервисов HRlink Cloud
    echo "Доступность облачных микросервисов:"
    urls1=(
        "license.hr-link.ru"
        "pinboard.hr-link.ru"
        "hrlk.ru"
        "pechkin.hr-link.ru"
        "esa.hr-link.ru"
    )
    urls2=(
        "zorro.hr-link.ru"
        "kronos.hr-link.ru"
    )

    for url in "${urls1[@]}"; do
        out=$(curl -s https://$url/api/v1/version --connect-timeout 5)
        echo -e "\t$url: $out"
    done

    for url in "${urls2[@]}"; do
        out=$(curl -s https://$url/actuator/info --connect-timeout 5)
        echo -e "\t$url: $out"
    done
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    ignore_errors="$1"

    clr_rst='\033[0m'
    clr_red='\033[0;31m'
    clr_grn='\033[0;32m'

    hardware_requirements
    permission_requirements
    package_requirements
    docker_version_requirements
    cloud_connectivity_requirements
fi
